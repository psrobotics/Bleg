﻿
EN   Your download at 07/27/2020 on PARTcommunity/PARTserver:

       Dear user,
       
       attached please find the following file of our 3D CAD download portal PARTcommunity/PARTserver powered by CADENAS:

       

       AIS2020, ATP30XL025-A-H10, ATP30XL025-A-H10.iam
       AIS2020, ATP30XL025-A-H10, ATP30XL025-A-H10_b.ipt
	
       Information for use:

       
       The attached file was compressed ("ZIP"), in order to ensure a faster download.
       In order to unpack the file you need a special decompressing software. 

       If you do not have a decompressing software installed, you can download it using one of the following links:
       PKZip® (http://www.pkware.com) or WinZip® (http://www.winzip.com)

       

       Please also check terms of use at http://www.cadenas.de/terms-of-use-3d-cad-models

       
       Best regards

       Your CADENAS GmbH
       support@cadenas.de



       >> Free APP for 3D CAD models <<
       
       Mobile access to 3D CAD models with your Smartphone or Tablet PC. 
       
       Download now at http://www.cadenas.de/en/app-store

       

       >> PARTcommunity - The network and information platform for engineers <<
       
       ■ Examples of use and ideas for components 
       ■ Information and experience exchange with other engineers

       Join the discussion now at http://www.partcommunity.com



       >> PARTsolutions - Find & manage standard, purchased, and own parts <<

       Reduce total product costs up to 70% in the development phase?

       In many companies PARTsolutions is one of the leading software systems helping
       engineers and purchasers to manage and find company-, supplier- and standard parts:

       ■ PURCHINEERING: Optimize cooperation of Purchasing and Engineering
       ■ Semiautomatic classification and intelligent search methods
       ■ Open for all systems such as PLM and ERP

       More information at http://www.cadenas.de/strategic-partsmanagement
       
       
       
       
